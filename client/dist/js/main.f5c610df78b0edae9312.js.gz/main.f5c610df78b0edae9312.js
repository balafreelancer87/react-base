"use strict";
(self["webpackChunkclient"] = self["webpackChunkclient"] || []).push([[179],{

/***/ 972:
/***/ (function(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {


// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(294);
// EXTERNAL MODULE: ./node_modules/react-dom/index.js
var react_dom = __webpack_require__(935);
;// CONCATENATED MODULE: ./src/assets/images/user.jpg
var user_namespaceObject = __webpack_require__.p + "assets/images/user.jpg";
;// CONCATENATED MODULE: ./src/assets/images/webpack-logo.svg
var webpack_logo_namespaceObject = __webpack_require__.p + "assets/images/webpack-logo.svg";
;// CONCATENATED MODULE: ./src/App.js
 // Import application sass styles


 // Test import of an asset

 // Test import of an asset


function App() {
  return /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement("h1", null, "React from Scratch"), /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement("h1", {
    className: "heading"
  }, "GeeksForGeeks"), /*#__PURE__*/react.createElement("h4", {
    className: "sub-heading"
  }, "A computer science klko portal for geeks ppol")), /*#__PURE__*/react.createElement("div", {
    className: "container"
  }, /*#__PURE__*/react.createElement("div", {
    className: "header"
  }, /*#__PURE__*/react.createElement("h1", null, "Welcome to React xxxx application"), /*#__PURE__*/react.createElement("div", {
    className: "postcss"
  }, "postcss"), /*#__PURE__*/react.createElement("img", {
    src: user_namespaceObject,
    alt: "react logo",
    style: {
      width: '400px'
    }
  }), /*#__PURE__*/react.createElement("img", {
    src: webpack_logo_namespaceObject,
    alt: "webpack logo",
    style: {
      width: '400px'
    }
  }))));
}
;// CONCATENATED MODULE: ./src/index.js



react_dom.render( /*#__PURE__*/react.createElement(App, null), document.querySelector("#root"));

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [216], function() { return __webpack_exec__(972); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.f5c610df78b0edae9312.js.map